## -----------------------------------------------------------------------------
library(AccumulatR)

## -----------------------------------------------------------------------------
spec <- race_spec() |>
  add_accumulator("left", "lognormal") |>
  add_accumulator("right", "lognormal") |>
  add_outcome("left", "left") |>
  add_outcome("right", "right")

model <- finalize_model(spec)

## -----------------------------------------------------------------------------
pars <- c(
  left.meanlog = log(0.28), left.sdlog = 0.16, left.q = 0, left.t0 = 0,
  right.meanlog = log(0.35), right.sdlog = 0.18, right.q = 0, right.t0 = 0
)

param_df <- build_param_matrix(spec, pars, n_trials = 6)
sim <- simulate(model, param_df, seed = 123)

sim[c("trial", "R", "rt")]

## -----------------------------------------------------------------------------
ctx <- build_likelihood_context(model, sim[c("trial", "R", "rt")])
log_likelihood(ctx, param_df)

