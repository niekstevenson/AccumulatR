## -----------------------------------------------------------------------------
library(AccumulatR)

## -----------------------------------------------------------------------------
model_spec <- race_spec() |>
  add_accumulator("R1_A", "LBA") |>
  add_accumulator("R1_B", "RDM") |>
  add_accumulator("R2", "lognormal") |>
  add_pool("R1", c("R1_A", "R1_B")) |>
  add_outcome("R1", "R1") |>
  add_outcome("R2", "R2")

structure <- finalize_model(model_spec)

true_params <- c(
  R1_A.v = 2,
  R1_A.B = 1,
  R1_A.A = .3,
  R1_A.sv = 1,
  R1_B.v = 3,
  R1_B.B = 1,
  R1_B.A = .3,
  R1_B.s = 1,
  R2.meanlog = log(0.4),
  R2.sdlog = 0.18
)

## -----------------------------------------------------------------------------
set.seed(123456)

n_trials <- 2000
params_df <- build_param_matrix(model_spec, true_params, n_trials = n_trials)

sim <- simulate(structure, params_df)

data_df <- data.frame(
  trial = sim$trial,
  R = factor(sim$R),
  rt = sim$rt,
  stringsAsFactors = FALSE
)

table(data_df$R)

## -----------------------------------------------------------------------------
ctx <- build_likelihood_context(structure, data_df)

params_df_true <- build_param_matrix(
  model_spec,
  true_params,
  n_trials = max(data_df$trial),
  layout = ctx$param_layout
)

ll_true <- as.numeric(log_likelihood(ctx, params_df_true))
ll_true

## -----------------------------------------------------------------------------
wrong_params <- true_params
wrong_params["R2.meanlog"] <- log(0.45)

params_df_wrong <- build_param_matrix(
  model_spec,
  wrong_params,
  n_trials = max(data_df$trial),
  layout = ctx$param_layout
)

ll_wrong <- as.numeric(log_likelihood(ctx, params_df_wrong))
ll_wrong

## -----------------------------------------------------------------------------
neg_loglik <- function(theta) {
  est <- true_params
  est["R1_A.v"] <- theta[["R1_A.v"]]
  est["R1_B.v"] <- theta[["R1_B.v"]]
  est["R1_A.B"] <- exp(theta[["log_B_shared"]])
  est["R1_B.B"] <- exp(theta[["log_B_shared"]])
  est["R2.meanlog"] <- theta[["R2.meanlog"]]
  est["R2.sdlog"] <- exp(theta[["log_R2.sdlog"]])
  params_df <- build_param_matrix(
    model_spec,
    est,
    n_trials = max(data_df$trial),
    layout = ctx$param_layout
  )
  ll <- log_likelihood(ctx, params_df)
  -as.numeric(ll)
}

start <- c(
  R1_A.v = 1.5,
  R1_B.v = 1.5,
  log_B_shared = log(1.0),
  R2.meanlog = log(0.32),
  log_R2.sdlog = log(0.15)
)

fit <- optim(start, neg_loglik, method = "Nelder-Mead", control = list(maxit = 4000, reltol = 1e-9))
fit_params <- c(
  R1_A.v = fit$par[["R1_A.v"]],
  R1_B.v = fit$par[["R1_B.v"]],
  B_shared = exp(fit$par[["log_B_shared"]]),
  R2.meanlog = fit$par[["R2.meanlog"]],
  R2.sdlog = exp(fit$par[["log_R2.sdlog"]])
)
target <- c(
  R1_A.v = true_params[["R1_A.v"]],
  R1_B.v = true_params[["R1_B.v"]],
  B_shared = true_params[["R1_A.B"]],
  R2.meanlog = true_params[["R2.meanlog"]],
  R2.sdlog = true_params[["R2.sdlog"]]
)
data.frame(true = target, recovered = fit_params, miss = abs(target - fit_params))


