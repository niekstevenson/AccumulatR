library(testthat)
library(AccumulatR)

test_check("AccumulatR")

