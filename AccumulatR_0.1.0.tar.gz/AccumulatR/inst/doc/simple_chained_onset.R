## -----------------------------------------------------------------------------
library(AccumulatR)

## -----------------------------------------------------------------------------
model_spec <- race_spec() |>
  add_accumulator("A", "lognormal") |>
  add_accumulator("B", "lognormal") |>
  add_accumulator("C", "lognormal", onset = after("B")) |>
  add_outcome("A", "A") |>
  add_outcome("C", "C")

structure <- finalize_model(model_spec)

true_params <- c(
  A.m = log(0.28),
  A.s = 0.14,
  A.q = 0,
  A.t0 = 0,
  B.m = log(0.1),
  B.s = 0.1,
  B.q = 0,
  B.t0 = 0,
  C.m = log(0.15),
  C.s = 0.1,
  C.q = 0,
  C.t0 = 0
)

## -----------------------------------------------------------------------------
set.seed(123456)

n_trials <- 2000
params_df <- build_param_matrix(model_spec, true_params, n_trials = n_trials)

sim <- simulate(structure, params_df)

data_df <- data.frame(
  trial = sim$trial,
  R = factor(sim$R),
  rt = sim$rt,
  stringsAsFactors = FALSE
)

table(data_df$R)

## -----------------------------------------------------------------------------
ctx <- build_likelihood_context(structure, data_df)

params_df_true <- build_param_matrix(
  model_spec,
  true_params,
  n_trials = max(data_df$trial),
  layout = ctx$param_layout
)

ll_true <- as.numeric(log_likelihood(ctx, params_df_true))
ll_true

## -----------------------------------------------------------------------------
wrong_params <- true_params
wrong_params["B.m"] <- log(0.14)

params_df_wrong <- build_param_matrix(
  model_spec,
  wrong_params,
  n_trials = max(data_df$trial),
  layout = ctx$param_layout
)

ll_wrong <- as.numeric(log_likelihood(ctx, params_df_wrong))
ll_wrong

## -----------------------------------------------------------------------------
neg_loglik <- function(theta) {
  est <- true_params
  est[c("A.m", "A.s", "B.m", "B.s", "C.m", "C.s")] <- theta[c("A.m", "A.s", "B.m", "B.s", "C.m", "C.s")]
  est[c("A.s", "B.s", "C.s")] <- exp(est[c("A.s", "B.s", "C.s")])
  params_df <- build_param_matrix(
    model_spec,
    est,
    n_trials = max(data_df$trial),
    layout = ctx$param_layout
  )
  ll <- log_likelihood(ctx, params_df)
  -as.numeric(ll)
}

start <- c(
  A.m = log(0.22),
  A.s = log(0.10),
  B.m = log(0.28),
  B.s = log(0.10),
  C.m = log(0.28),
  C.s = log(0.10)
)

fit <- optim(start, neg_loglik, method = "Nelder-Mead")

fit_params <- fit$par
fit_params[c("A.s", "B.s", "C.s")] <- exp(fit_params[c("A.s", "B.s", "C.s")])
target <- true_params[c("A.m", "A.s", "B.m", "B.s", "C.m", "C.s")]

data.frame(
  true = target,
  recovered = fit_params,
  miss = abs(target - fit_params)
)

