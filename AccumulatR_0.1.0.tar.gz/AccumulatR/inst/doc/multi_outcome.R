## -----------------------------------------------------------------------------
library(AccumulatR)

## -----------------------------------------------------------------------------
model_spec <- race_spec(n_outcomes = 2L) |>
  add_accumulator("A", "lognormal") |>
  add_accumulator("B", "lognormal") |>
  add_outcome("A", "A") |>
  add_outcome("B", "B")

structure <- finalize_model(model_spec)

true_params <- c(
  A.m = log(0.30),
  A.s = 0.18,
  A.q = 0,
  A.t0 = 0,
  B.m = log(0.38),
  B.s = 0.22,
  B.q = 0,
  B.t0 = 0
)

## -----------------------------------------------------------------------------
set.seed(123456)

n_trials <- 500
params_df <- build_param_matrix(model_spec, true_params, n_trials = n_trials)

sim <- simulate(structure, params_df)

data_df <- data.frame(
  trial = sim$trial,
  R = factor(sim$R),
  rt = sim$rt,
  R2 = factor(sim$R2),
  rt2 = sim$rt2,
  stringsAsFactors = FALSE
)

table(data_df$R, data_df$R2)
summary(data_df$rt2 - data_df$rt)

## -----------------------------------------------------------------------------
ctx <- build_likelihood_context(structure, data_df)

params_df_true <- build_param_matrix(
  model_spec,
  true_params,
  n_trials = max(data_df$trial),
  layout = ctx$param_layout
)

ll_true <- as.numeric(log_likelihood(ctx, params_df_true))
ll_true

## -----------------------------------------------------------------------------
wrong_params <- true_params
wrong_params["B.m"] <- log(0.55)

params_df_wrong <- build_param_matrix(
  model_spec,
  wrong_params,
  n_trials = max(data_df$trial),
  layout = ctx$param_layout
)

ll_wrong <- as.numeric(log_likelihood(ctx, params_df_wrong))
ll_wrong

## -----------------------------------------------------------------------------
neg_loglik <- function(theta) {
  est <- true_params
  est[c("A.m", "A.s", "B.m", "B.s")] <- theta[c("A.m", "A.s", "B.m", "B.s")]
  est[c("A.s", "B.s")] <- exp(est[c("A.s", "B.s")])
  params_df <- build_param_matrix(
    model_spec,
    est,
    n_trials = max(data_df$trial),
    layout = ctx$param_layout
  )
  ll <- log_likelihood(ctx, params_df)
  -as.numeric(ll)
}

start <- c(
  A.m = log(0.24),
  A.s = log(0.12),
  B.m = log(0.48),
  B.s = log(0.12)
)

fit <- optim(start, neg_loglik, method = "Nelder-Mead")

fit_params <- fit$par
fit_params[c("A.s", "B.s")] <- exp(fit_params[c("A.s", "B.s")])
target <- true_params[c("A.m", "A.s", "B.m", "B.s")]

data.frame(
  true = target,
  recovered = fit_params,
  miss = abs(target - fit_params)
)

