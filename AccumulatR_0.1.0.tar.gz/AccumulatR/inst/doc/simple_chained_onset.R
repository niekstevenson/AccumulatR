## -----------------------------------------------------------------------------
library(AccumulatR)

## -----------------------------------------------------------------------------
model_spec <- race_spec() |>
  add_accumulator("A", "lognormal") |>
  add_accumulator("B", "lognormal") |>
  add_accumulator("C", "lognormal", onset = after("B")) |>
  add_outcome("A", "A") |>
  add_outcome("C", "C")

structure <- finalize_model(model_spec)

true_params <- c(
  A.meanlog = log(0.28),
  A.sdlog = 0.14,
  B.meanlog = log(0.1),
  B.sdlog = 0.1, 
  C.meanlog = log(0.15),
  C.sdlog = 0.1 
)

## -----------------------------------------------------------------------------
set.seed(123456)

n_trials <- 2000
params_df <- build_param_matrix(model_spec, true_params, n_trials = n_trials)

sim <- simulate(structure, params_df)

data_df <- data.frame(
  trial = sim$trial,
  R = factor(sim$R),
  rt = sim$rt,
  stringsAsFactors = FALSE
)

table(data_df$R)

## -----------------------------------------------------------------------------
ctx <- build_likelihood_context(structure, data_df)

params_df_true <- build_param_matrix(
  model_spec,
  true_params,
  n_trials = max(data_df$trial),
  layout = ctx$param_layout
)

ll_true <- as.numeric(log_likelihood(ctx, params_df_true))
ll_true

## -----------------------------------------------------------------------------
wrong_params <- true_params
wrong_params["B.meanlog"] <- log(0.14)

params_df_wrong <- build_param_matrix(
  model_spec,
  wrong_params,
  n_trials = max(data_df$trial),
  layout = ctx$param_layout
)

ll_wrong <- as.numeric(log_likelihood(ctx, params_df_wrong))
ll_wrong

## -----------------------------------------------------------------------------
neg_loglik <- function(theta) {
  # optimize on unconstrained scale for sdlog
  theta[c("A.sdlog", "B.sdlog", "C.sdlog")] <- exp(theta[c("A.sdlog", "B.sdlog", "C.sdlog")])
  params_df <- build_param_matrix(
    model_spec,
    theta,
    n_trials = max(data_df$trial),
    layout = ctx$param_layout
  )
  ll <- log_likelihood(ctx, params_df)
  -as.numeric(ll)
}

start <- c(
  A.meanlog = log(0.22),
  A.sdlog = log(0.10),
  B.meanlog = log(0.28),
  B.sdlog = log(0.10),
  C.meanlog = log(0.28),
  C.sdlog = log(0.10)
)

fit <- optim(start, neg_loglik, method = "Nelder-Mead")

fit_params <- fit$par
fit_params[c("A.sdlog", "B.sdlog", "C.sdlog")] <- exp(fit_params[c("A.sdlog", "B.sdlog", "C.sdlog")])

data.frame(
  true = true_params,
  recovered = fit_params,
  miss = abs(true_params - fit_params)
)

