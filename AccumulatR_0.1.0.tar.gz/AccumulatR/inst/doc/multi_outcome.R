## -----------------------------------------------------------------------------
library(AccumulatR)

## -----------------------------------------------------------------------------
model_spec <- race_spec(n_outcomes = 2L) |>
  add_accumulator("A", "lognormal") |>
  add_accumulator("B", "lognormal") |>
  add_outcome("A", "A") |>
  add_outcome("B", "B")

structure <- finalize_model(model_spec)

true_params <- c(
  A.meanlog = log(0.30),
  A.sdlog = 0.18,
  B.meanlog = log(0.38),
  B.sdlog = 0.22
)

## -----------------------------------------------------------------------------
set.seed(123456)

n_trials <- 500
params_df <- build_param_matrix(model_spec, true_params, n_trials = n_trials)

sim <- simulate(structure, params_df)

data_df <- data.frame(
  trial = sim$trial,
  R = factor(sim$R),
  rt = sim$rt,
  R2 = factor(sim$R2),
  rt2 = sim$rt2,
  stringsAsFactors = FALSE
)

table(data_df$R, data_df$R2)
summary(data_df$rt2 - data_df$rt)

## -----------------------------------------------------------------------------
ctx <- build_likelihood_context(structure, data_df)

params_df_true <- build_param_matrix(
  model_spec,
  true_params,
  n_trials = max(data_df$trial),
  layout = ctx$param_layout
)

ll_true <- as.numeric(log_likelihood(ctx, params_df_true))
ll_true

## -----------------------------------------------------------------------------
wrong_params <- true_params
wrong_params["B.meanlog"] <- log(0.55)

params_df_wrong <- build_param_matrix(
  model_spec,
  wrong_params,
  n_trials = max(data_df$trial),
  layout = ctx$param_layout
)

ll_wrong <- as.numeric(log_likelihood(ctx, params_df_wrong))
ll_wrong

## -----------------------------------------------------------------------------
neg_loglik <- function(theta) {
  # optimize on unconstrained scale for sdlog
  theta[c("A.sdlog", "B.sdlog")] <- exp(theta[c("A.sdlog", "B.sdlog")])
  params_df <- build_param_matrix(
    model_spec,
    theta,
    n_trials = max(data_df$trial),
    layout = ctx$param_layout
  )
  ll <- log_likelihood(ctx, params_df)
  -as.numeric(ll)
}

start <- c(
  A.meanlog = log(0.24),
  A.sdlog = log(0.12),
  B.meanlog = log(0.48),
  B.sdlog = log(0.12)
)

fit <- optim(start, neg_loglik, method = "Nelder-Mead")

fit_params <- fit$par
fit_params[c("A.sdlog", "B.sdlog")] <- exp(fit_params[c("A.sdlog", "B.sdlog")])

data.frame(
  true = true_params,
  recovered = fit_params,
  miss = abs(true_params - fit_params)
)

